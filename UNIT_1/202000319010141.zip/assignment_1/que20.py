# 16. Write a Python program that will demonstrate the use of Identity Operators.

num1 = 2
num2 = 2

print("demonstrate the use of Identity Operators: ")

print("num1 is num2:", num1 is num2)
print("num1 is not num2:", num1 is not num2)

# 13. Write a Python program to find length of string.

stringValue = "hello"

print("length of string: ", len(stringValue))

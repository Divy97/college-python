# 35. Write a program to display last five characters of string.

stringValue = input('Enter a string: ')
print("last five characters of string:", stringValue[-5::])

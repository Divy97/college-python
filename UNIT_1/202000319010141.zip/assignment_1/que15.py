# 15. Write a Python program that will demonstrate the use of Arithmetic Operators.

num1 = 2
num2 = 2

print("demonstrate the use of Arithmetic Operators: ")

print("num1 + num2: ", num1 + num2)
print("num1 - num2: ", num1 - num2)
print("num1 * num2: ", num1 * num2)
print("num1 / num2: ", num1 / num2)
print("num1 % num2: ", num1 % num2)
print("num1 // num2: ", num1 // num2)
print("num1 ** num2: ", num1 ** num2)

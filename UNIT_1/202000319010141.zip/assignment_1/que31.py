# 31. Write a program to calculate the sum of 5 subject and find the percentage.

subject1 = 56
subject2 = 78
subject3 = 66
subject4 = 98
subject5 = 78

total = subject1 + subject2 + subject3 + subject4 + subject5
percentage = total / 5

print("Total marks: ", total)
print("Percentage marks: ", percentage, "%")

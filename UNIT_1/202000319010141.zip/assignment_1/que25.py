# 25. Write a Python program which asks the user to input a string. Find the sub-string in given
# string. (Hint: Welcome in GLS University, Find the position of ‘Uni’ from given string)

stringValue = input("Enter a string: ")
subStringValue = input("Enter a sub string: ")

print("Substring is present in string: ", stringValue.find(subStringValue))

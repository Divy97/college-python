# 26. Write a Python program which asks the user to input a string and perform lstrip and rstrip
# function on input string.

stringValue = input("Enter a string: ")

print("lstrip('8')", stringValue.lstrip('8'))
print("rstrip('8')", stringValue.rstrip('8'))

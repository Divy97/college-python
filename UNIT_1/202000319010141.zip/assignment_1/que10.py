# 10. Write a Python program to calculate the area of rectangle and square.

length = 10
width = 20

print("Area of rectangle: ", length*width)
print("Area of square: ", length*length)

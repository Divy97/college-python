# 33. Write a program to display reverse the string.

stringValue = input('Enter a string: ')
print("Reversed string:", "".join(reversed(stringValue)))

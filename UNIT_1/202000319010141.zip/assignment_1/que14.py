# 14. Write a Python program that will perform following conversions using appropriate method:

# 1. string to integer
stringValue = "2"
strToInt = int(stringValue)
print(type(strToInt))

# 2. integer to float
intValue = 2
intToFloat = float(intValue)
print(type(intToFloat))

# 3. tuple to list
tupleValue = (1, 2, 3, 4, 5)
tupleToList = list(tupleValue)
print(type(tupleToList))

# 4. string to list
stringValue = "Hello"
strToList = list(stringValue)
print(type(strToList))

# 5. list to tuple
listValues = [1, 2, 3, 4, 5]
listToTuple = tuple(listValues)
print(type(listToTuple))

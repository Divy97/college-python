# 27. Write a Python program which asks the user to input a string. Perform the following
# operations:
# Slicing operation
# Concatenate by using + and , operator


stringValue = 'string'
print("Slicing:", stringValue[2:5])
print("concat " + "a", "String")

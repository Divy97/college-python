# 22. Write a Python program which have string str = “Hello World”, count how many times ‘l’
# is repeated in str using count()function

stringValue = "Hello World"

print("count('l'): ", stringValue.count('l'))

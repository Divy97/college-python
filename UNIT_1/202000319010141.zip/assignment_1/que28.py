# 28. Write a Python program which asks the user to input a string. Use endswith and startwith
# operations on input string.


stringValue = input("Enter a string: ")

print("startswith('h'):", stringValue.startswith('h'))
print("endswith('h'):", stringValue.endswith('h'))

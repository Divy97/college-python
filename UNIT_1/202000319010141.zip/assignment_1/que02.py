# Create a Python program to demonstrate the use of comments(single and multi-line)

# single line comment

"""
    multiline comment
"""

# 7. Create a Python program that will have one tuple of vegetables with values = (‘Potato',
# ‘Brinjal’,‘Tomato’,‘Cabbage’, ‘Cauliflower’). Perform following operations:
# • Print whole tuple
# • Print only first element of tuple
# • Prints elements starting from 2nd till 4th
# • Prints elements starting from 2nd element till last
# • Print whole tuple twice using appropriate operator.


vegetableTuple = ('Potato', 'Brinjal', 'Tomato', 'Cabbage', 'Cauliflower')

print("TUPLE: ", vegetableTuple)
print("first element of tuple: ", vegetableTuple[0])
print("elements starting from 2nd till 4th: ", vegetableTuple[1:4])
print("elements starting from 2nd till last: ", vegetableTuple[1:])
print("Print whole tuple twice: ", vegetableTuple*2)

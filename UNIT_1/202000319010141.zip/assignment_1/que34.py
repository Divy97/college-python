# 34. Write a program to display alternate character in string.

stringValue = input('Enter a string: ')
print("Alternate characters of string:", stringValue[::2])

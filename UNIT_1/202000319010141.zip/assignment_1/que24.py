# 24. Write a Python program which asks the user to input a string. Convert that string into
# title case.


stringValue = input("Enter a string: ")
print("title case:", stringValue.title())

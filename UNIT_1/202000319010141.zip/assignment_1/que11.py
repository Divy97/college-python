# 11. Write a Python program to swap of two numbers.

num1 = 1
num2 = 2
print("Num1 and Num2 before swapping: ", num1, num2)

# swap logic
temp = num1
num1 = num2
num2 = temp
print("Num1 and Num2 after swapping: ", num1, num2)

# 23. Write a Python program which asks the user to input a string. Convert that string into
# opposite case than inputted by user. F o r e x a m p l e : s t r = “ P y t H o n ” t h a n
# o u t p u t = “ p Y T h O N ”

stringValue = input("Enter a string: ")
print("Swap case:", stringValue.swapcase())

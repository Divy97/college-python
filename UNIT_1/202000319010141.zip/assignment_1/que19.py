# 16. Write a Python program that will demonstrate the use of Logical Operators.

num1 = 2
num2 = 2

print("demonstrate the use of Logical Operators: ")

print("AND OPERATOR: (num1 > num2 and num2 > num1):",
      (num1 > num2 and num2 > num1))
print("OR OPERATOR: (num1 < num2 or num2 < num1):", (num1 < num2 or num2 < num1))
print("NOT OPERATOR: not(num1 < num2 or num2 < num1):",
      not (num1 < num2 or num2 < num1))

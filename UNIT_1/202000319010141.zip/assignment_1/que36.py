# 36. Write a program to display first Five characters

stringValue = input('Enter a string: ')
print("First five characters of string:", stringValue[0:5:])

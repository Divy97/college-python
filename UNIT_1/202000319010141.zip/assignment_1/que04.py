# 4. Create a Python program that will have one string variable =“Welcome to Python”.
# Perform following operations:
# • Print whole string
# • Print only first character of string
# • Print 3rd character to -1 character of string using slicing operator
# • Print string from 4th character to the end of string using slicing operator
# • Print whole string 5 times using appropriate operator

stringVariable = "Welcome to Python"

print("whole string is ", stringVariable)
print("3rd character to -1 character of string is ", stringVariable[3:-1])
print("4th character to the end of string is ", stringVariable[4:])
print("whole string 5 times ", stringVariable*5)

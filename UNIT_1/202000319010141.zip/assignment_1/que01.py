# 1. Print a Hello message on interactive screen.

print("Hello world")

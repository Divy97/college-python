# 21. Write a Python program that will demonstrate the use of Membership Operators.

stringValue = "HELLO"

print("'H' in HELLO: ", 'H' in stringValue)
print("'H' not in HELLO: ", 'H' not in stringValue)

# 9. Write a Python program that will display numbers from 1 to 20(both inclusive) using
# range()function

rangeValues = range(1, 21)

for i in rangeValues:
    print(i)

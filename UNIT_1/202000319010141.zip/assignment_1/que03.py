# 3. Create a Python program that will have 3 variables which stores integer, float and
# complex value. Display its value and also demonstrate its datatype class using type().

number = 10
floatNumber = 2.33
complexValue = 2 + 3j

print("Datatype class of ", number, " is ", type(number))
print("Datatype class of ", floatNumber, " is ", type(floatNumber))
print("Datatype class of ", complexValue, " is ", type(complexValue))

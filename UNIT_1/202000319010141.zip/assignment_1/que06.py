# 6. Create a Python program that will have one fruit dictionary with fruit values. Display
# keys and values separately.

fruitDictionary = {
    1: 'Mango',
    2: 'Banana',
    3: 'Apple',
    4: 'Strawberry',
    5: 'Pomegranate'
}

print("KEYS ", fruitDictionary.keys())
print("VALUES ", fruitDictionary.values())

# 8. Write a Python program that will demonstrate the use of Sting Functions.

stringValue = "Hello"

print("capitalize(): ", stringValue.capitalize())
print("count('l'): ", stringValue.count('l'))
print("find('o'): ", stringValue.find('o'))
print("islower(): ", stringValue.islower())
print("isupper(): ", stringValue.isupper())
print("isdigit(): ", stringValue.isdigit())
print("isalpha(): ", stringValue.isalpha())
print("lower(): ", stringValue.lower())
print("upper(): ", stringValue.upper())
print("endswith('o'): ", stringValue.endswith('o'))
print("startswith('H'): ", stringValue.startswith('H'))

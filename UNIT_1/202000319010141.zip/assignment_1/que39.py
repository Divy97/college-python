# 39. Write a program to display whether string contains only space or not.

stringValue = input('Enter a string: ')

if (stringValue.isspace()):
    print("string contains only space")
else:
    print("string does not contains only space")

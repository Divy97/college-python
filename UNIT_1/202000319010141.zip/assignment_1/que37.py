# 37. Write a program to display middle character of string.

stringValue = input('Enter a string: ')

middle = int(len(stringValue) / 2)
print("middle character of string:", stringValue[middle])

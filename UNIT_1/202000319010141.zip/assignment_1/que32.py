# 32. Write a program to get the Python version.

import sys
print("Python version: ", sys.version)
